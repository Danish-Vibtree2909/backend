/* eslint-disable camelcase */
export default interface IForgotPass{
    username : string,
    password : string,
    temp_token : number
}
