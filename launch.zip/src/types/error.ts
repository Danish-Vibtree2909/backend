export default interface IError{

    name : string,
    message : string,
    stack : string
}
