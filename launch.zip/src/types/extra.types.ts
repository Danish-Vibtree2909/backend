
export interface IDate {
    date : String,
    month : String,
    year : String
}
