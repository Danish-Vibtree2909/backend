export default interface IAvater{
    filename:string,
    uploadpath : string,
    completepath : string
}
