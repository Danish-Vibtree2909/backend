
export interface IMail {
    from : string,
    to: string,
    subject : string,
    html : string
}
