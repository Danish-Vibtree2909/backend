
export default interface IPasswordChanegeGetParams{
    token : string,
    username : string
}
