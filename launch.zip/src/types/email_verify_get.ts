
export default interface IEmailVerifyParam {
    token : string,
    email : string
}
