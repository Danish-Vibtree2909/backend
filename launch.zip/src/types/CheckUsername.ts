export default interface ICheckUserName{
    username: string
}
