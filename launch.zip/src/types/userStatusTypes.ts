import {Document} from 'mongoose';

export default interface userStatusInterface extends Document{
 
    authId : string;
    userId : any;
    status : string;
    
}