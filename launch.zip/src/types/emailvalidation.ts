export interface IEmailValid{
    email:string;
}
